<?php
$servername = "localhost";
$username = "id21127808_root";
$password = "4444@Four";
$dbname = "id21127808_info";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($_SERVER["REQUEST_METHOD"] === "POST") {
  $fineIds = $_POST["finearr"];
  $vehicleNo = $_POST["vehicleNumber"];
  $voucher_no = $_POST['voucher_no'];
  
  $fineIdsStr = implode(',', $fineIds);
  $query = "SELECT * FROM fine_transactions WHERE vehicle_no = '$vehicleNo' AND fine_id IN ($fineIdsStr)";
  $runq = mysqli_query($conn, $query);

  if ($runq->num_rows == 0) {
    $insertQuery = "INSERT INTO fine_transactions (voucher_no, vehicle_no, fine_id) VALUES (?, ?, ?)";
    $stmt = $conn->prepare($insertQuery);
    $stmt->bind_param("isi", $voucher_no, $vehicleNo, $fineId);

    foreach ($fineIds as $fineId) {
      $fineId = intval($fineId); // Ensure it's an integer
      if ($stmt->execute()) {
        echo "Payment for Fine ID $fineId successful!<br>";
      } else {
        echo "Payment for Fine ID $fineId failed.<br>";
      }
    }
    
    // Update payment status to "Paid" in vehicles_and_fines table
    $updateQuery = "UPDATE vehicles_and_fines SET payment_status = 'paid' WHERE vehicle_no = ?";
    $updateStmt = $conn->prepare($updateQuery);
    $updateStmt->bind_param("i", $vehicleNo);
    $updateStmt->execute();
    
  } else {
    echo "Duplicate payment detected.";
  }
}
?>
