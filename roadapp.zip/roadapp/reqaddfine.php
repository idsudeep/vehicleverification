<?php
error_reporting(E_ALL);


if ($_SERVER['REQUEST_METHOD'] == 'POST') {
        $servername = "localhost";
    $username = "id21127808_root";
    $password = "4444@Four";
    $dbname = "id21127808_info";

    $conn = new mysqli($servername, $username, $password, $dbname);

    // Check the connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }
    
    $vehicleNumber = $_POST['vehicleNumber'];
    $ruleViolationDescription = $_POST['violationDescription'];
    $fineAmount = $_POST['fineAmount'];
   
    $currentDate = date('Y-m-d');
    
     $query =" select * from vehicles where vehicle_no = '$vehicleNumber'";
    $rq = mysqli_query($conn,$query);
    
    if($rq->num_rows == 0 ){
          $json = array("statusCode"=>400 , "message"=> "Vehicle Number is not Registered");
         echo json_encode($json, JSON_PRETTY_PRINT);
        die();
    }

    // Check if a record with the same rule violation description and current date already exists
    $checkQuery = "SELECT COUNT(*) AS count FROM vehicles_and_fines WHERE rule_violation_description = '$ruleViolationDescription' AND DATE(rule_violation_date) = '$currentDate'";
    $checkResult = $conn->query($checkQuery);

    if ($checkResult && $checkResult->fetch_assoc()['count'] > 0) {
        $json = array("statusCode" => 400, "message" => "Duplicate entry for the same violation on the current date.");
        echo json_encode($json, JSON_PRETTY_PRINT);
        die();
    }

    // Proceed with insertion
    $insertQuery = "INSERT INTO vehicles_and_fines (vehicle_no, rule_violation_description, fine_amount) VALUES ('$vehicleNumber', '$ruleViolationDescription', $fineAmount)";

    if ($conn->query($insertQuery) === TRUE) {
        $json = array("statusCode" => 200, "message" => "Fine added successfully.");
        echo json_encode($json, JSON_PRETTY_PRINT);
    } else {
        $json = array("statusCode" => 500, "message" => "Error adding fine: " . $conn->error);
        echo json_encode($json, JSON_PRETTY_PRINT);
    }

    // Close the database connection
    $conn->close();
} else {
    http_response_code(403); // Forbidden
    echo "Access denied.";
}
?>
