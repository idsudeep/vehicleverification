<?php
error_reporting(E_ALL);

// Check if the request is an AJAX request
if ($_SERVER['REQUEST_METHOD']=='GET') {
    // Proceed with your original code
    $servername = "localhost";
    $username = "id21127808_root";
    $password = "4444@Four";
    $dbname = "id21127808_info";

    $conn = new mysqli($servername, $username, $password, $dbname);

    // Check the connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    $vehicleNumber = isset($_GET['vehicleNumber']) ? $_GET['vehicleNumber'] : '';
    $vehicleNumber = mysqli_real_escape_string($conn, $vehicleNumber);

    if (empty($vehicleNumber)) {
       
         $json = array("statusCode"=>404 , "message"=> "Please provide a valid vehicle number");
         echo json_encode($json, JSON_PRETTY_PRINT);
        die();
    }
    
    $query =" select * from vehicles where vehicle_no = '$vehicleNumber'";
    $rq = mysqli_query($conn,$query);
    
    if($rq->num_rows == 0 ){
          $json = array("statusCode"=>404 , "message"=> "Entered Vehicle Number  is not Registered");
         echo json_encode($json, JSON_PRETTY_PRINT);
        die();
    }

    // Fetch data from the database
    $sql = "SELECT v.vehicle_no, v.vehicle_type, v.owner_name, v.registration_date, f.fine_id, f.rule_violation_date, f.rule_violation_description, f.fine_amount, f.payment_status, (SELECT MAX(tax_year) FROM vehicle_taxes WHERE vehicle_no = v.vehicle_no) AS tax_year FROM vehicles v LEFT JOIN vehicles_and_fines f ON v.vehicle_no = f.vehicle_no WHERE v.vehicle_no = '$vehicleNumber'";
    $result = $conn->query($sql);

    $jsonArray = array();

    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $vehicleNo = $row['vehicle_no'];
            $vehicleDetails = array(
                "vehicle_no" => $row['vehicle_no'],
                "vehicle_type" => $row['vehicle_type'],
                "owner_name" => $row['owner_name'],
                "registration_date" => $row['registration_date'],
                "tax_year" => $row['tax_year']
            );

            $fine = array(
                "fine_id" => $row['fine_id'],
                "rule_violation_date" => $row['rule_violation_date'],
                "rule_violation_description" => $row['rule_violation_description'],
                "fine_amount" => floatval($row['fine_amount']),
                "payment_status" => $row['payment_status']
            );

            if (!isset($jsonArray[$vehicleNo])) {
                $jsonArray[$vehicleNo] = array(
                    "vehicle_details" => $vehicleDetails,
                    "fine_details" => array()
                );
            }

            $jsonArray[$vehicleNo]['fine_details'][] = $fine;
        }
        $jsonData = array_values($jsonArray);
        echo json_encode($jsonData, JSON_PRETTY_PRINT);
    } else {
        
        $json = array("statusCode"=>404, "message"=> "Vehicle is up to date ");
        echo json_encode($json, JSON_PRETTY_PRINT);
    } 

    $conn->close();
} else {
    http_response_code(403); // Forbidden
    echo "Access denied.";
}
?>
