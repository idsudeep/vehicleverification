-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Aug 28, 2023 at 05:18 PM
-- Server version: 10.5.20-MariaDB
-- PHP Version: 7.3.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `id21127808_info`
--

-- --------------------------------------------------------

--
-- Table structure for table `fine_transactions`
--

CREATE TABLE `fine_transactions` (
  `voucher_no` int(11) NOT NULL,
  `vehicle_no` varchar(20) NOT NULL,
  `transaction_date` timestamp NOT NULL DEFAULT current_timestamp(),
  `fine_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `fine_transactions`
--

INSERT INTO `fine_transactions` (`voucher_no`, `vehicle_no`, `transaction_date`, `fine_id`) VALUES
(122, '5796', '2023-08-26 18:22:59', 1),
(122, '5796', '2023-08-26 18:22:59', 2);

-- --------------------------------------------------------

--
-- Table structure for table `vehicles`
--

CREATE TABLE `vehicles` (
  `id` int(11) NOT NULL,
  `vehicle_no` varchar(20) NOT NULL,
  `owner_name` varchar(100) NOT NULL,
  `vehicle_type` varchar(50) DEFAULT NULL,
  `registration_date` date DEFAULT NULL,
  `color` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `vehicles`
--

INSERT INTO `vehicles` (`id`, `vehicle_no`, `owner_name`, `vehicle_type`, `registration_date`, `color`) VALUES
(1, '5796', 'Rocky', 'bike', '2023-03-30', 'blue');

-- --------------------------------------------------------

--
-- Table structure for table `vehicles_and_fines`
--

CREATE TABLE `vehicles_and_fines` (
  `vehicle_no` varchar(20) NOT NULL,
  `fine_id` int(11) NOT NULL,
  `rule_violation_date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `rule_violation_description` varchar(255) NOT NULL,
  `fine_amount` decimal(10,2) NOT NULL,
  `payment_status` enum('paid','unpaid') DEFAULT 'unpaid'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `vehicles_and_fines`
--

INSERT INTO `vehicles_and_fines` (`vehicle_no`, `fine_id`, `rule_violation_date`, `rule_violation_description`, `fine_amount`, `payment_status`) VALUES
('5796', 1, '2023-08-26 18:22:59', 'No Helmet while riding', 250.00, 'paid'),
('5796', 2, '2023-08-26 18:22:59', 'Signal Violation', 200.00, 'paid');

-- --------------------------------------------------------

--
-- Table structure for table `vehicle_taxes`
--

CREATE TABLE `vehicle_taxes` (
  `id` int(11) NOT NULL,
  `vehicle_no` varchar(20) DEFAULT NULL,
  `tax_year` date NOT NULL,
  `tax_amount` decimal(10,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `vehicle_taxes`
--

INSERT INTO `vehicle_taxes` (`id`, `vehicle_no`, `tax_year`, `tax_amount`) VALUES
(1, '5796', '2023-03-30', 4000.00);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `fine_transactions`
--
ALTER TABLE `fine_transactions`
  ADD KEY `vehicle_no` (`vehicle_no`);

--
-- Indexes for table `vehicles`
--
ALTER TABLE `vehicles`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `vehicle_number` (`vehicle_no`);

--
-- Indexes for table `vehicles_and_fines`
--
ALTER TABLE `vehicles_and_fines`
  ADD PRIMARY KEY (`fine_id`),
  ADD UNIQUE KEY `unique_fine` (`rule_violation_date`,`rule_violation_description`),
  ADD KEY `fk_vehicle_no` (`vehicle_no`);

--
-- Indexes for table `vehicle_taxes`
--
ALTER TABLE `vehicle_taxes`
  ADD PRIMARY KEY (`id`),
  ADD KEY `vehicle_no` (`vehicle_no`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `vehicles`
--
ALTER TABLE `vehicles`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `vehicles_and_fines`
--
ALTER TABLE `vehicles_and_fines`
  MODIFY `fine_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `vehicle_taxes`
--
ALTER TABLE `vehicle_taxes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `fine_transactions`
--
ALTER TABLE `fine_transactions`
  ADD CONSTRAINT `fine_transactions_ibfk_1` FOREIGN KEY (`vehicle_no`) REFERENCES `vehicles` (`vehicle_no`);

--
-- Constraints for table `vehicles_and_fines`
--
ALTER TABLE `vehicles_and_fines`
  ADD CONSTRAINT `fk_vehicle_no` FOREIGN KEY (`vehicle_no`) REFERENCES `vehicles` (`vehicle_no`);

--
-- Constraints for table `vehicle_taxes`
--
ALTER TABLE `vehicle_taxes`
  ADD CONSTRAINT `vehicle_taxes_ibfk_1` FOREIGN KEY (`vehicle_no`) REFERENCES `vehicles` (`vehicle_no`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
